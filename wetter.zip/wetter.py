### FAnToM Session
### API Version: 20140515
### Used core version:    GITDIR-NOTFOUND (GITDIR-NOTFOUND)
### Used toolbox version: GITDIR-NOTFOUND (GITDIR-NOTFOUND)

################################################################
###                  Reset GUI                               ###
################################################################
fantom.ui.setCamera( 0, fantom.ui.Camera( fantom.math.Vector3(51, 10, 25.9545), fantom.math.Vector3(51, 10, 24.9545), fantom.math.Vector3(0, 1, 0), 1, -7.65778e-314 ) )
fantom.ui.setCamera( 1, fantom.ui.Camera( fantom.math.Vector3(0, 3.8637, 0), fantom.math.Vector3(0, 2.8637, 0), fantom.math.Vector3(0, 0, 1), 0, 1 ) )
fantom.ui.setCamera( 2, fantom.ui.Camera( fantom.math.Vector3(0, 0, 3.8637), fantom.math.Vector3(0, 0, 2.8637), fantom.math.Vector3(0, 1, 0), 0, 1 ) )
fantom.ui.setCamera( 3, fantom.ui.Camera( fantom.math.Vector3(3.8637, 0, 0), fantom.math.Vector3(2.8637, 0, 0), fantom.math.Vector3(0, 0, 1), 0, 1 ) )

fantom.ui.setClippingPlane( fantom.ui.ClippingPlane( 0, fantom.math.Matrix4( (1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1) ), False ) )
fantom.ui.setClippingPlane( fantom.ui.ClippingPlane( 1, fantom.math.Matrix4( (1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1) ), False ) )
fantom.ui.setClippingPlane( fantom.ui.ClippingPlane( 2, fantom.math.Matrix4( (1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1) ), False ) )
fantom.ui.setClippingPlane( fantom.ui.ClippingPlane( 3, fantom.math.Matrix4( (1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1) ), False ) )
fantom.ui.setClippingPlane( fantom.ui.ClippingPlane( 4, fantom.math.Matrix4( (1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1) ), False ) )
fantom.ui.setClippingPlane( fantom.ui.ClippingPlane( 5, fantom.math.Matrix4( (1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1) ), False ) )

fantom.ui.setBackgroundColor( fantom.math.Color(0, 0, 0, 1) )

fantom.ui.setRotationCenter( fantom.ui.RotationCenter( fantom.math.Vector3(0, 0, 0), True, True, True ) )


################################################################
###                  Create algorithms                       ###
################################################################
Load_GeoData = fantom.makeAlgorithm("Load/GeoData")
Load_GeoData.setName( "Load/GeoData" )
Load_GeoData.setOption("Input File", "/home/celentano/Downloads/fantom/praktikum/wetter.dat")
fantom.ui.setAlgorithmPosition(Load_GeoData, fantom.math.Vector2(0, 35))

Grid_Generate = fantom.makeAlgorithm("Grid/Generate")
Grid_Generate.setName( "Grid/Generate" )
Grid_Generate.setOption("Type", "2D")
Grid_Generate.setOption("nx", 20)
Grid_Generate.setOption("ny", 20)
Grid_Generate.setOption("nz", 10)
Grid_Generate.setOption("Center", fantom.math.Vector3(51, 10, 0))
Grid_Generate.setOption("dx", 0.5)
Grid_Generate.setOption("dy", 0.5)
Grid_Generate.setOption("dz", 1)
fantom.ui.setAlgorithmPosition(Grid_Generate, fantom.math.Vector2(170.399, 39))

GeoData_ShowPoints = fantom.makeAlgorithm("Geo Data/Show Points")
GeoData_ShowPoints.setName( "Geo Data/Show Points" )
GeoData_ShowPoints.setOption("Color", fantom.math.Color(1, 0, 0, 1))
GeoData_ShowPoints.setOption("Size", 0.5)
GeoData_ShowPoints.setOption("Temp min", 0)
GeoData_ShowPoints.setOption("Temp max", 20)
GeoData_ShowPoints.setOption("slider", 0)
fantom.ui.setAlgorithmPosition(GeoData_ShowPoints, fantom.math.Vector2(347.891, 284))
GeoData_ShowPoints.setVisualOutputVisible('labels', False)
GeoData_ShowPoints.setVisualOutputVisible('points', True)

GeoData_ShowPoints_2 = fantom.makeAlgorithm("Geo Data/Show Points")
GeoData_ShowPoints_2.setName( "Geo Data/Show Points::2" )
GeoData_ShowPoints_2.setOption("Color", fantom.math.Color(1, 0, 0, 1))
GeoData_ShowPoints_2.setOption("Size", 0.5)
GeoData_ShowPoints_2.setOption("Temp min", 0)
GeoData_ShowPoints_2.setOption("Temp max", 20)
GeoData_ShowPoints_2.setOption("slider", 0)
fantom.ui.setAlgorithmPosition(GeoData_ShowPoints_2, fantom.math.Vector2(0, 239))
GeoData_ShowPoints_2.setVisualOutputVisible('labels', False)
GeoData_ShowPoints_2.setVisualOutputVisible('points', False)

Grid_ShowGrid = fantom.makeAlgorithm("Grid/Show Grid")
Grid_ShowGrid.setName( "Grid/Show Grid" )
Grid_ShowGrid.setOption("Line color", fantom.math.Color(0, 0, 1, 1))
Grid_ShowGrid.setOption("Random jittering of color", True)
Grid_ShowGrid.setOption("Random seed", 0)
Grid_ShowGrid.setOption("Line width", 1.5)
fantom.ui.setAlgorithmPosition(Grid_ShowGrid, fantom.math.Vector2(396, 60))
Grid_ShowGrid.setVisualOutputVisible('grid', True)

VisPraktikum_Interpolate_Shepard_1 = fantom.makeAlgorithm("VisPraktikum/Interpolate/Shepard_1")
VisPraktikum_Interpolate_Shepard_1.setName( "VisPraktikum/Interpolate/Shepard_1" )
VisPraktikum_Interpolate_Shepard_1.setOption("p", 2)
fantom.ui.setAlgorithmPosition(VisPraktikum_Interpolate_Shepard_1, fantom.math.Vector2(228, 150))



################################################################
###                     Make Connections                     ###
################################################################
VisPraktikum_Interpolate_Shepard_1.connect("Interpolated", GeoData_ShowPoints, "Field")
VisPraktikum_Interpolate_Shepard_1.connect("InterpolatedDomain", GeoData_ShowPoints, "Domain")
Load_GeoData.connect("Points", VisPraktikum_Interpolate_Shepard_1, "Points")
Load_GeoData.connect("Temperature", VisPraktikum_Interpolate_Shepard_1, "Field")
Load_GeoData.connect("Points", GeoData_ShowPoints_2, "Domain")
Load_GeoData.connect("Temperature", GeoData_ShowPoints_2, "Field")
Grid_Generate.connect("grid", VisPraktikum_Interpolate_Shepard_1, "InterpolationPoints")
Grid_Generate.connect("grid", Grid_ShowGrid, "Grid")


################################################################
###                      Run algorithms                      ###
################################################################
fantom.scheduleAllNecessary()